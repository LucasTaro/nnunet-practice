from pathlib import Path
import fitz
from PIL import Image,ImageDraw
p=Path(__file__).resolve().parent;d=fitz.open(p/'nnUNet_v2_数据处理与训练全流程.pdf');o=p/'rendered';o.mkdir(exist_ok=True)
for i,pg in enumerate(d):pg.get_pixmap(matrix=fitz.Matrix(1.3,1.3)).save(o/f'{i+1:02}.png')
for k in range(4):
 canvas=Image.new('RGB',(1500,1320),'#dde2e9')
 for j in range(6):
  i=k*6+j
  if i>=len(d):break
  im=Image.open(o/f'{i+1:02}.png');im.thumbnail((740,416));x=j%2*750;y=j//2*440;canvas.paste(im,(x,y));ImageDraw.Draw(canvas).text((x+5,y+416),f'Page {i+1}',fill='black')
 canvas.save(o/f'contact{k}.png')
