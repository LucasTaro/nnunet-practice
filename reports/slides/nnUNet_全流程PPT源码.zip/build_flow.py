from pathlib import Path
from pptx import Presentation
from pptx.util import Inches
from PIL import Image
P=Path(__file__).resolve().parent
BASE=P
ns={'__file__':str(BASE/'build_ppt.py')};exec((BASE/'build_ppt.py').read_text().split('# 1\n')[0],ns)
R=ns['R'];t=ns['text'];b=ns['box'];ln=ns['line'];arr=ns['arrow'];card=ns['card'];band=ns['band'];flow=ns['flow'];table=ns['table'];code=ns['code'];slide=ns['slide'];note=ns['note'];B=ns['BLUE'];T=ns['TEAL'];G=ns['GRAY'];L=ns['LIGHT']
def pic(s,f,x,y,w,h):
 p=BASE/'reference_assets'/f;iw,ih=Image.open(p).size;q=min(w/iw,h/ih)
 s.shapes.add_picture(str(p),Inches(x+(w-iw*q)/2),Inches(y+(h-ih*q)/2),width=Inches(iw*q),height=Inches(ih*q))
def S(title,sub,notes=''):
 s=slide(title,sub,'依据：nnU-Net v2 默认实现；官方源码核对 2026-11-06。数值小例子均为教学示例。');note(s,notes);return s
def nums(s,vals,x,y,size=.48):
 for i,v in enumerate(vals):b(s,x+i*(size+.1),y,size,size,T if v else L);t(s,x+i*(size+.1),y+.07,size,size-.07,str(v),15,'FFFFFF' if v else B)
#1
s=S('nnU-Net v2｜从数据准备到模型训练','数据几何 · 强度处理 · 自动规划 · Patch 采样 · 多尺度监督','建议讲解约22分钟；前14页聚焦数据，后续解释训练机制和配置。可按需要略讲CLI页。')
t(s,.9,2,8,1.7,'理解每一次数据变换\n以及它为什么影响训练',36,bold=True)
pic(s,'三维切片.jpeg',9,1.7,3.0,2.8)
flow(s,[('数据','几何与标签一致'),('规划','确定空间视野'),('预处理','统一表达'),('训练','局部采样与优化')],4.7)
#2
s=S('01  完整流程：哪些在训练前，哪些在训练中？','Fingerprint 负责统计；Planner 决定配置；Preprocessor 执行变换；Trainer 学习权重。')
flow(s,[('准备数据','影像 / 标签\ndataset.json'),('Fingerprint','Spacing / Shape\n强度统计'),('Plans','间距 / Patch\n拓扑 / Batch'),('Preprocess','转置 / 裁剪\n归一化 / 重采样')],2)
flow(s,[('动态取 Patch','随机 / 前景引导'),('增强与训练','空间变换 / Loss / 更新'),('完整验证','滑窗 / 空间恢复 / 指标')],4.5)
#3
s=S('02  数据准备：先建立正确的空间与标签契约','文件尺寸一致只是必要检查之一；还必须检查方向、间距、位置与类别语义。')
code(s,.8,1.95,5.6,2.65,'Dataset001_Example/\n  imagesTr/case001_0000.nii.gz\n  imagesTr/case001_0001.nii.gz\n  labelsTr/case001.nii.gz\n  dataset.json',16)
card(s,6.7,1.95,5.75,3.9,'准备阶段的四项检查','几何：Shape / Spacing / Affine\n多通道：同一病例各序列已经对齐\n标签：整数类别、背景0、无非法值\n划分：同一患者不跨训练 / 验证集',T)
t(s,.95,4.95,5.5,.9,'_0000、_0001 表示输入通道。\nchannel_names 决定默认归一化映射。',18)
band(s,'框架不会通过 resize 自动修复错位，也不会可靠地从影像内容猜测 CT / MRI 模态。')
#4
s=S('03  Image、标签 Mask、有效区 Mask 是三种对象','“Mask”不是唯一一种数据；不同对象决定了哪些操作允许执行。')
table(s,['对象','数值含义','允许的处理'],[['Image','连续影像强度','强度归一化、连续插值、强度增强'],['分割标签','0 背景；1、2、3 为不同类别','同步空间变换；标签专用插值；不做 Z-score'],['有效区 Mask','True / False：有效影像区域','控制裁剪或归一化统计范围']],y=2,h=2.8)
flow(s,[('同一空间变换','图像与标签同步'),('不同数值处理','图像强度 ≠ 类别编号'),('恢复原始空间','保存裁剪与坐标属性')],5)
#5
s=S('04  Fingerprint：统计数据集，不提前训练网络','默认分析原始间距、非零裁剪后尺寸、裁剪比例与前景强度等；此处不执行目标网格重采样。')
flow(s,[('各病例读取','Spacing\nShape'),('有效区裁剪统计','shapes_after_crop\n裁剪体积比例'),('前景强度采样','每通道均值 / 标准差\n分位数'),('数据集摘要','dataset_fingerprint.json')],2.2)
card(s,.8,4.45,5.7,1.55,'几何统计 → 网络规划','决定目标间距、典型尺寸与训练视野。',B)
card(s,6.75,4.45,5.7,1.55,'强度统计 → 归一化','CT 使用训练集前景统计；MRI 常逐病例计算。',T)
#6
s=S('05  Target Spacing：先逐轴中位数，再检查各向异性','每一列独立计算统计量；目标间距不必来自某一个病例，也不要求变成 1×1×1 mm。')
table(s,['病例','轴0 (mm)','轴1 (mm)','轴2 (mm)'],[['A','1','1','3'],['B','1','1','5'],['C','1','1','7'],['D','1','1','9'],['E','1','1','11'],['中位数','1','1','7']],x=.8,y=1.9,w=5.8,h=3.8)
card(s,6.9,1.9,5.55,3.8,'厚层轴调整示例','中位 Shape = [256,256,40]\n7 > 3×1，且 40×3 < 256\n两条件满足 → 该轴取10%分位数\n[3,5,7,9,11] → P10 = 3.8\n目标间距：[1,1,3.8] mm',T)
band(s,'这是 Planner 的间距规则；执行重采样时是否分轴，还要由重采样器判断。')
note(s,'默认阈值3。间距条件为最粗轴 > 3×其余轴最大间距；尺寸条件为该轴中位尺寸×3 < 其余轴最小中位尺寸。若P10小于其余轴最大间距，代码还有保护性调整。支持手动overwrite。')
#7
s=S('06  重采样后的 Shape：保持物理范围，改变网格密度','各病例共享目标 Spacing，但预处理后的完整 Volume Shape 仍然可以不同。')
t(s,1,1.95,11.6,.7,'N_new[i] = round(N_crop[i] × S_old[i] / S_target[i])',25,B,True)
flow(s,[('裁剪后原始数据','Shape [20,256,256]\nSpacing [5,1,1]'),('指定目标间距','[2.5,0.5,0.5] mm\n三个方向采样均加密'),('目标数组','Shape [40,512,512]\n体素总数增加8倍')],3.1)
band(s,'Shape 与 Spacing 必须采用相同轴序；插值新增体素，不增加真正采集到的医学信息。')
note(s,'近似物理覆盖范围按N×Spacing解释。严格中心坐标范围涉及N−1与插值坐标约定，不影响此处默认compute_new_shape公式。此示例假设已经完成裁剪和轴序处理。')
#8
s=S('07  Separate-Z：先平面，再低分辨率轴','不是先做一次完整 XYZ 重采样，再重复处理 Z；Z 表示低分辨率轴，不固定对应数组第三轴。')
flow(s,[('原数组','[20,256,256]\n低分辨率轴长度20'),('平面内插值','[20,512,512]\n每层二维插值，层数不变'),('低分辨率轴插值','[40,512,512]\n仅改变第一轴长度')],2.05)
card(s,.8,4.25,5.7,1.6,'分轴路径','平面内用 order；低分辨率轴用 order_z。',B)
card(s,6.75,4.25,5.7,1.6,'非分轴路径','直接整体空间插值；此时 order_z 不参与。',T)
band(s,'force_separate_z=None：根据原始 / 目标间距与轴唯一性判断，不是每个病例都强制分轴。')
#9
s=S('08  插值阶数与标签专用路径','order 控制插值阶数；它不是训练超参数，也不是卷积核大小。')
table(s,['order','方法','一维教学例子'],[['0','最近邻','x=0强度10，x=1强度20；x=0.25 → 10'],['1','线性插值','x=0.25 → 0.75×10 + 0.25×20 = 12.5'],['3','三次插值','利用更大邻域；结果还取决于边界约定']],y=1.9,h=2.2)
code(s,.8,4.45,5.7,1.45,'image: is_seg=False, order=3\nlabel: is_seg=True,  order=1\nSeparate-Z: order_z=0',16)
card(s,6.75,4.45,5.7,1.45,'标签 [1,3] 不能平均成类别2','按类别二值图插值，再重建离散标签。',T)
note(s,'例如类别1指示[1,0]、类别3指示[0,1]；25%位置得分0.75/0.25，输出1。0阶可直接最近邻。重建中的阈值、argmax和平局策略依具体依赖版本和分支而异，不能把当前master当所有v2版本。')
#10
s=S('09  CT 与 MRI：差异主要在强度归一化','方案由通道元数据及规划规则确定；不是根据验证成绩动态搜索归一化方法。')
table(s,['维度','CTNormalization','MRI 常用 ZScoreNormalization'],[['强度基础','HU通常具有可比较的物理意义','绝对强度随设备、序列、扫描变化'],['统计范围','整个训练数据集的前景强度样本','当前病例、当前输入通道'],['强度截断','前景0.5%～99.5%分位数','默认不使用同一套CT截断'],['归一化','统一训练集mean / std','每病例mean / std'],['推理','复用训练集统计，无需真值标签','对新病例计算其自身统计']],y=1.95,h=3.85)
band(s,'默认流程不自动加入 MRI 偏置场校正或直方图匹配；有效区 Mask 与器官真值 Mask 不同。')
#11
s=S('10  Z-score 与非零裁剪：统计区域必须说清楚','默认顺序：Transpose → Crop → Normalize → Resample；归一化不会改变体素坐标。')
card(s,.8,1.9,5.7,3.9,'Z-score 的数值例子','强度：[10,20,30,40]\nμ=25；σ=√125≈11.1803\nz=(x−μ)/max(σ,ε)\n结果：[-1.342,-0.447,0.447,1.342]\n不使用 Mask 时，背景零值也参与统计。',B)
card(s,6.75,1.9,5.7,3.9,'裁剪 Bounding Box 例子','原 Shape：[10,12,8]\n有效索引：2～7 / 3～9 / 1～5\nbbox = [[2,8],[3,10],[1,6]]\n裁剪：image[2:8,3:10,1:6]\n新 Shape：[6,7,5]；标签使用同一框。',T)
band(s,'多通道非零区域取并集并填孔；填的是有效区掩膜，不是把原始影像的零强度改成1。')
note(s,'std采用总体标准差，分母N。若有效区mask启用，常通过seg>=0表达有效区。默认规划会结合裁剪比例与归一化类能力决定是否使用mask。裁剪框左闭右开，恢复时还要撤销重采样和transpose。')
#12
s=S('11  Patch 与网络共同规划：空间视野必须放得进显存','显存目标是估算预算，不是当前GPU剩余显存的实时测量。')
flow(s,[('典型数据尺度','目标Spacing\n重采样后中位Shape'),('初始Patch / 拓扑','物理视野\n卷积核 / 下采样'),('估算资源开销','各级特征图\n显存预算'),('调整并生成Plans','Patch可整除性\n最小特征图 / Batch')],2.05)
card(s,.8,4.35,5.7,1.55,'各向异性可能影响早期拓扑','例如 kernel=[1,3,3]、stride=[1,2,2]。',B)
card(s,6.75,4.35,5.7,1.55,'尺度逐渐接近后使用完整3D操作','空间尺寸过小时停止相应轴的下采样。',T)
band(s,'Patch 大小由 Plans 决定；每次训练只动态改变位置，不按当前器官大小临时改变网络输入。')
#13
s=S('12  Foreground Sampling：先决定样本类型，再选位置','默认确定性模式按 Batch 内的样本索引分配；不是每次独立以33%概率抛硬币。')
code(s,.8,1.9,6.6,1.5,'threshold = round(B * (1 - p))\nforce_fg = sample_index >= threshold',19)
table(s,['B=2，p=0.33','索引0','索引1'],[['threshold=1','普通随机','强制前景']],x=.8,y=3.7,w=6.6,h=1.3)
card(s,7.7,1.9,4.75,3.8,'前景引导路径','先选病例\n从现有前景类别中选类别\n从该类候选坐标中选一个体素\n围绕该体素构造采样框\n无可用前景时可退回随机',T)
band(s,'普通随机 Patch 也可能有器官；强制前景采样比例不等于最终“含前景Patch”的比例。')
note(s,'前景候选坐标来自预处理保存的class_locations或版本对应的前景位置存储。也支持概率oversampling模式，但非此默认分配示例。Ignore label任务还有额外采样分支。')
#14
s=S('13  Patch Bounding Box：固定大小，动态起点','以下示例采用当前官方上下界约束逻辑，无额外增强 Padding；旧版本右边界处理可能不同。')
code(s,.8,1.9,5.65,2.3,'N = [100,120,80]\nP = [40,40,32]\nallowed_start = [0,0,0] ... [60,80,48]\nstart = clip(v - P//2, lb, ub)\nend = start + P',16)
table(s,['前景坐标 v','起点 start','终点 end'],[['[50,70,30]','[30,50,14]','[70,90,46]'],['[5,10,4]','[0,0,0]','[40,40,32]'],['[95,115,75]','[60,80,48]','[100,120,80]']],x=6.75,y=1.95,w=5.7,h=2.8)
t(s,.95,4.7,11.4,1.1,'随机采样：从每个轴允许的起点区间抽整数。\n病例小于 Patch：先取框与影像的交集，再对缺失区域显式 Padding。',21)
band(s,'1D例：病例长24、Patch长32 → 有效数据24 + 两侧各补4；不能用负索引切片替代Padding。')
#15
s=S('14  裁剪与增强顺序：先取大块，再生成最终Patch','扩大初始采样块提供变换所需的上下文，但不保证完整器官始终留在最终视野。')
pic(s,'Data_Augmentation.jpeg',.8,1.9,6.1,3.8)
for j,(title,body) in enumerate([('P_load','较大初始块'),('空间变换','旋转 / 缩放'),('P_final','固定网络输入')]):
 x=.8+j*4;b(s,x,6.0,3.7,.78,L);t(s,x+.12,6.06,1.6,.42,title,17,B,True);t(s,x+1.6,6.12,2,.42,body,14)
 if j<2:arr(s,x+3.74,6.25,.22)

card(s,7.25,1.9,5.2,3.75,'两种尺寸不要混淆','initial_patch_size：增强前取样尺寸\npatch_size：最终网络输入尺寸\n例：128²旋转45°的包围框约181²\n实际由旋转 / 缩放范围共同估计\n空间变换同步作用于图像和标签',T)
note(s,'配图为用户提供的通用增强示例，并非默认nnUNet全部增强清单；当前默认SpatialTransform p_elastic_deform=0。增强可通过输出网格到输入的坐标映射直接生成最终尺寸，不一定先生成大旋转数组再另行crop。各向异性可采用dummy2D增强，但网络仍可为3D。')
#16
s=S('15  从普通 U-Net 到 ResEnc L：改变架构，也改变规划预算','ResEnc L 是残差编码器U-Net的规划预设，不是固定Patch的单一网络，也不是预训练模型。')
flow(s,[('残差块内部','F(x) + S(x)\n特征相加 Add'),('U-Net跨层连接','Encoder → Decoder\n通道拼接 Concat'),('ResEnc L Planner','约24GB级别预算\n重估Patch / Batch')],2)
card(s,.8,4.4,5.7,1.6,'主要改动在 Encoder','残差捷径有助于优化；Decoder仍做上采样与拼接。',B)
card(s,6.75,4.4,5.7,1.6,'训练方案通常继续使用标准 Trainer','SGD、Poly LR、Dice组合损失与深监督仍保留。',T)
band(s,'比较标准U-Net与ResEnc L，是比较完整配置；不能把所有收益都归因于残差连接。',6.45)
note(s,'官方resenc_presets推荐ResEnc L。2d/3d_fullres通常可共享标准预处理数据，3d_lowres可能不同。M/L/XL是资源预设，实际显存非严格保证。参考arXiv:2404.09556。')
#17
s=S('16  Deep Supervision：中间Decoder也接受分割监督','成熟训练技术，并非nnU-Net首创；各尺度分割头输出逐体素logits，不是整幅影像分类。')
for i,(y,dim,wgt) in enumerate([(2,'32³','1/7'),(3.3,'64³','2/7'),(4.6,'128³','4/7')]):
 b(s,.9,y,2.1,.7,B);t(s,1.05,y+.12,1.8,.45,'Decoder '+dim,18,'FFFFFF',True);arr(s,3.15,y+.25,.45)
 b(s,3.8,y,2.2,.7,L);t(s,3.95,y+.12,1.9,.45,'1×1×1 分割头',17,B);arr(s,6.15,y+.25,.45)
 b(s,6.8,y,2.3,.7,L);t(s,6.95,y+.12,2,.45,'logits + 同尺度标签',15,B);arr(s,9.3,y+.25,.45)
 t(s,10,y+.1,2.3,.5,'Loss × '+wgt,21,T,True)
 if i<2:ln(s,1.9,y+.7,1.9,y+1.3,T)
band(s,'总 Loss = Σ wₛLₛ；高分辨率权重更大。推理通常只使用最终全分辨率输出。')
note(s,'图示为4个输出中最粗输出权重0后的3个有效尺度，权重4/7,2/7,1/7。默认初始权重1/2^i，最低分辨率单设备置0，DDP可能极小权重。标签下采样保持类别语义。中间监督提供额外梯度路径和多尺度语义约束；最粗尺度可能丢失小目标。')
#18
s=S('17  训练配方：优化器由Trainer定义，不由Planner搜索','标准基线将优化器、调度器、Loss和增强作为一套经过验证的训练方案。')
card(s,.8,1.95,3.75,3.95,'SGD + Nesterov','LR₀=0.01\nMomentum=0.99\nWeight decay=3e−5\n默认1000 epochs\n通常250训练迭代/epoch',B)
card(s,4.8,1.95,3.75,3.95,'Poly LR','lr(t)=lr₀(1−t/T)^0.9\nT=1000时：\nt=0：0.01000\nt=500：0.00536\nt=900：0.00126',T)
card(s,8.8,1.95,3.75,3.95,'Loss 组合','互斥类别：Dice + CE\nRegion任务：Dice + BCE\n默认多类别Dice不计背景\n多个尺度加权：Deep Supervision\n负Dice项可使总Loss为负',B)
band(s,'AdamW不是禁用选项；通过自定义Trainer实现，并重新匹配学习率与权重衰减。')
#19
s=S('18  从训练步到完整体积验证：两类指标不要混用','在线Patch验证监控优化；完整Volume验证才评估整个病例的分割结果。')
flow(s,[('train_step','取Patch → 前向\nLoss → 反向 → 更新'),('在线验证','采样Patch\nPseudo Dice / EMA'),('完整验证','重叠滑窗\nGaussian加权融合'),('空间恢复','恢复分辨率 / 裁剪\n撤销转置 / 保存NIfTI')],2.1)
card(s,.8,4.5,5.7,1.5,'记录可复现的实验状态','Plans、splits、Trainer、软件版本、日志与权重。',B)
card(s,6.75,4.5,5.7,1.5,'评价最终模型','逐病例 / 逐器官指标、跨折统计、独立测试。',T)
band(s,'检查预测与原始影像能否正确叠加；Shape一致并不自动意味着物理空间一致。',6.45)
#20
s=S('19  CLI：优先修改有明确实验目的的参数','准确命令：nnUNetv2_plan_and_preprocess；本机支持选项以 -h 为准。')
table(s,['目的','参数','实际影响'],[['首次准备 / 验证','-d 1 --verify_dataset_integrity','选择数据集并检查一致性'],['控制资源和处理范围','-c 3d_fullres -np 2 -npfp 4','预处理配置 / CPU进程 / RAM负载'],['仅检查规划 / 更新统计','--no_pp / --clean','跳过预处理 / 刷新Fingerprint'],['架构预设 / 显存预算','-pl nnUNetPlannerResEncL / -gpu_memory_target','网络规划与Patch、Batch'],['分辨率消融','-overwrite_target_spacing a b c','目标网格与后续资源开销'],['保留独立实验配置','-overwrite_plans_name MyPlans','训练、预测时用 -p MyPlans']],y=1.9,h=3.8)
band(s,'Optimizer、LR、Loss权重、Epoch、增强和前景比例通常通过自定义Trainer修改（训练用 -tr）。')
note(s,'-fpe和-preprocessor_name供自定义指纹提取器和预处理器。--clean不等于清除所有旧缓存和权重。ResEnc默认Plans名nnUNetResEncUNetLPlans；训练命令nnUNetv2_train 1 3d_fullres 0 -p nnUNetResEncUNetLPlans。改spacing要确认轴序和缓存标识。')
#21 only experiment
s=slide('20  实验配置示例：将上述机制映射到一个实际任务','本页集中展示用户实验；其他页面介绍默认算法或教学示例。','依据：用户两份训练日志与环境记录；最终验证均值仅对应Fold 0。')
table(s,['维度','实际配置'],[['数据','TotalSegmentator MRI；23例三器官子集；Fold 0：18训练/5验证'],['预处理','ZScoreNormalization；use_mask=False；Spacing [1.875,1.6016,1.4583]'],['网络输入','PlainConvUNet / 3d_fullres；Patch [96,128,192]；Batch 2'],['网络拓扑','6级；卷积核均为3³；末级stride=[1,2,2]'],['运行环境（用户记录）','Python 3.11；nnU-Net v2.8.1；CUDA 12.8；RTX PRO 6000'],['日志结果','Epoch 999结束；完整体积 Mean Validation Dice = 0.92988']],y=1.9,h=3.9,widths=[2.6,9.1])
band(s,'此结果不是五折均值或独立测试集成绩；模型配置与软件环境记录需随实验一同保存。')
#22
s=S('21  总结：一条可解释、可复现的数据—训练链路','理解每一步的输入、输出和责任边界，才能判断改动是否合理。')
flow(s,[('数据契约','几何一致\n类别语义正确'),('规则规划','间距 / 网络 / Patch\n匹配数据与预算'),('一致变换','图像与标签同步\n强度与类别分开处理'),('可靠训练与评估','动态Patch与深监督\n完整体积验证')],2.1)
t(s,1,4.4,11.2,1.5,'① 统一 Spacing，不等于统一完整 Volume Shape。\n② 非零裁剪、训练采样、增强输出裁剪，是不同操作。\n③ 规划决定训练条件；Trainer决定学习策略；验证检验最终效果。',23,bold=True)
t(s,.95,6.25,11.4,.5,'参考：Isensee et al., Nature Methods 2021；nnU-Net Revisited 2024；官方nnunetv2源码。',13,G)
# output with slide notes for every page
import json
for i,s in enumerate(R.slides,1):
 if not s.notes_slide.notes_text_frame.text.strip():s.notes_slide.notes_text_frame.text='讲解重点：'+ '\n'.join(sh.text for sh in s.shapes if sh.has_text_frame and sh.top<Inches(6.9))
 for sh in s.shapes:assert sh.left>=0 and sh.top>=0 and sh.left+sh.width<=R.slide_width+10000 and sh.top+sh.height<=R.slide_height+10000,(i,sh.name)
R.save(P/'nnUNet_v2_数据处理与训练全流程.pptx')
(P/'slides.json').write_text(json.dumps([{'page':i,'notes':s.notes_slide.notes_text_frame.text} for i,s in enumerate(R.slides,1)],ensure_ascii=False,indent=2))
print('22 slides generated')
