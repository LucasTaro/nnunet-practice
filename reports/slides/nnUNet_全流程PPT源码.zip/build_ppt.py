from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN
from pptx.oxml.xmlchemy import OxmlElement
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_TICK_MARK
from pathlib import Path
import re,json
OUT=Path(__file__).resolve().parent; R=Presentation(); R.slide_width=Inches(13.333); R.slide_height=Inches(7.5)
BG='F7F9FC'; INK='172B4D'; BLUE='2764B7'; TEAL='168B87'; GRAY='5C6B7E'; LIGHT='E9EFF7'; ORANGE='C87D32'; WHITE='FFFFFF'
def rgb(c):return RGBColor.from_string(c)
def box(s,x,y,w,h,fill=WHITE,line=None,shape=MSO_SHAPE.ROUNDED_RECTANGLE):
 a=s.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h));a._element.spPr.append(OxmlElement('a:effectLst'));a.fill.solid();a.fill.fore_color.rgb=rgb(fill);a.line.fill.background() if not line else None
 if line:a.line.color.rgb=rgb(line)
 if shape==MSO_SHAPE.ROUNDED_RECTANGLE:a.adjustments[0]=.08
 return a
def text(s,x,y,w,h,t,size=20,color=INK,bold=False,font='Noto Sans CJK SC',align=None):
 a=s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h));tf=a.text_frame;tf.word_wrap=True;tf.margin_left=Pt(2);tf.margin_right=Pt(2);tf.margin_top=Pt(2);tf.margin_bottom=Pt(2)
 for i,line in enumerate(t.split('\n')):
  p=tf.paragraphs[0] if i==0 else tf.add_paragraph();p.text=line;p.font.name=font;p.font.size=Pt(size);p.font.bold=bold;p.font.color.rgb=rgb(color);p.space_after=Pt(9)
  if align is not None:p.alignment=align
 return a
def line(s,x1,y1,x2,y2,c=GRAY,width=1.5):
 a=s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1), Inches(y1), Inches(x2), Inches(y2));a.line.color.rgb=rgb(c);a.line.width=Pt(width);return a
def arrow(s,x,y,w=.35,h=.22,c=BLUE):return box(s,x,y,w,h,c,shape=MSO_SHAPE.RIGHT_ARROW)
def slide(title,kicker,source='来源：nnU-Net 官方文档；技术原理示意'):
 s=R.slides.add_slide(R.slide_layouts[6]);s.background.fill.solid();s.background.fill.fore_color.rgb=rgb(BG)
 box(s,.48,.38,.07,.43,TEAL,shape=MSO_SHAPE.RECTANGLE);text(s,.72,.31,11.9,.6,title,28,bold=True)
 text(s,.73,1.02,11.9,.65,kicker,16,GRAY);line(s,.75,6.99,12.6,6.99,LIGHT)
 text(s,.75,7.09,11.2,.23,source,9,GRAY);text(s,12,7.05,.6,.3,f'{len(R.slides):02}',11,GRAY)
 return s
def note(s,t):s.notes_slide.notes_text_frame.text=t

def card(s,x,y,w,h,title,body,c=BLUE):
 box(s,x,y,w,h);box(s,x,y,w,.06,c,shape=MSO_SHAPE.RECTANGLE);text(s,x+.18,y+.2,w-.36,.5,title,21,c,True);text(s,x+.18,y+.85,w-.36,h-.95,body,18)
def band(s,t,y=6.25):box(s,.8,y,11.75,.52,LIGHT);text(s,1,y+.04,11.35,.43,t,16,BLUE)
def flow(s,items,y=2.7):
 n=len(items);w=(11.7-(n-1)*.36)/n
 for i,(a,b) in enumerate(items):
  x=.8+i*(w+.36);box(s,x,y,w,1.6);text(s,x+.1,y+.15,w-.2,.5,a,18,BLUE,True);text(s,x+.1,y+.75,w-.2,.7,b,15)
  if i<n-1:arrow(s,x+w+.04,y+.65,.28)
def table(s,headers,rows,x=.8,y=2,w=11.7,h=3.8,widths=None):
 sh=s.shapes.add_table(len(rows)+1,len(headers), Inches(x), Inches(y), Inches(w), Inches(h));t=sh.table
 if widths:
  for col,cw in zip(t.columns,widths):col.width=Inches(cw)
 for i,row in enumerate([headers]+rows):
  for j,val in enumerate(row):
   c=t.cell(i,j);c.text=str(val);c.fill.solid();c.fill.fore_color.rgb=rgb(BLUE if i==0 else WHITE if i%2 else LIGHT)
   c.margin_left=Inches(.13);c.margin_top=Inches(.07)
   for p in c.text_frame.paragraphs:p.font.name='Noto Sans CJK SC';p.font.size=Pt(16);p.font.color.rgb=rgb(WHITE if i==0 else INK);p.font.bold=i==0
 return sh

def grid(s,x,y,n=5,cell=.28,c=BLUE):
 for i in range(n):
  for j in range(n):box(s,x+i*cell,y+j*cell,cell-.02,cell-.02,LIGHT if (i+j)%3 else c,shape=MSO_SHAPE.RECTANGLE)
def stack(s,x,y,w=3,h=1.1,depth=5,dy=.3):
 for i in reversed(range(depth)):
  box(s,x+i*.13,y-i*dy,w,h,'D7E5F5',BLUE,MSO_SHAPE.PARALLELOGRAM)

def code(s,x,y,w,h,t,size=17):box(s,x,y,w,h,INK);text(s,x+.2,y+.16,w-.4,h-.25,t,size,WHITE,font='DejaVu Sans Mono')
SRC='来源：用户提供的两份训练日志（2026-11-03 / 11-04）'

# 1
