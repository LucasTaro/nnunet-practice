# nnU-Net v2 数据处理与训练全流程

22页16:9演示文稿，重点为默认算法与数值示例。用户实验仅在第21页集中介绍。
运行：安装 python-pptx、Pillow 后执行 python build_flow.py。build_ppt.py为本地绘图工具模块。
渲染：LibreOffice转PDF，再运行render.py（需要PyMuPDF）。

## 内容与检查
基于官方默认实现讲解；小数组与数值例子不是实验结果。
重点包括目标Spacing、各向异性规划、Separate-Z、插值阶数、CT/MRI归一化、有效区/标签Mask、裁剪、Patch规划、前景采样、边界Padding、增强、ResEnc L、Deep Supervision、训练损失、优化器与CLI。
全部页面已渲染检查；修复封面图遮挡、增强页流程图过低、实验表格换行拥挤。
采样bbox采用核对时master的双边界约束，旧版可能仅约束下界，已在页内标注。
插值标签重建和平局策略受依赖版本影响；不将master描述为所有历史版本。
参考增强图仅为通用方法展示，不是标准Trainer启用增强的完整清单。

## 来源
官方代码核对日期：2026-11-06。相关快照附于sources/。
https://github.com/MIC-DKFZ/nnUNet/tree/master/nnunetv2
https://github.com/MIC-DKFZ/nnUNet/blob/master/documentation/resenc_presets.md
https://doi.org/10.1038/s41592-020-01008-z
https://arxiv.org/abs/2404.09556
两张示意图由用户仓库提供，原始权属未独立核验，见reference_assets/。
